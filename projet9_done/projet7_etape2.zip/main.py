
from projet7.models.utilisateur import Utilisateur
from projet7.models.trajet import Trajet
from projet7.models.trajet_express import TrajetExpress
from projet7.services.persistence import sauvegarder, charger
from projet7.services.logger import log_info
from projet7.services.analyse import analyser_reservations

def main():
    utilisateurs = charger()

    if not utilisateurs:
        log_info("Initialisation des données")
        alice = Utilisateur("Alice")
        t1 = Trajet("Paris", "Lyon", 460)
        t2 = TrajetExpress("Paris", "Marseille", 750)

        alice.reserver(t1)
        alice.reserver(t2)

        utilisateurs.append(alice)
        sauvegarder(utilisateurs)

    for u in utilisateurs:
        u.afficher()

    analyser_reservations()

if __name__ == "__main__":
    main()
