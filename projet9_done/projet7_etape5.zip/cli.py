
import typer
from rich.console import Console
from rich.table import Table

from projet7.services.persistence import charger, sauvegarder
from projet7.models.trajet import Trajet
from projet7.models.trajet_express import TrajetExpress
from projet7.models.utilisateur import Utilisateur
from projet7.services.analyse import analyser_reservations
from projet7.services.visualisation import (
    afficher_histogramme_utilisateurs,
    afficher_camembert_types
)

app = typer.Typer()
console = Console()

@app.command()
def reserver(nom: str, depart: str, arrivee: str, distance: float, type: str = "normal"):
    utilisateurs = charger()
    utilisateur = next((u for u in utilisateurs if u.nom == nom), None)

    if utilisateur is None:
        utilisateur = Utilisateur(nom)
        utilisateurs.append(utilisateur)

    trajet = TrajetExpress(depart, arrivee, distance) if type == "express" else Trajet(depart, arrivee, distance)
    utilisateur.reserver(trajet)

    sauvegarder(utilisateurs)
    console.print(f"✅ Réservation ajoutée pour [bold]{nom}[/bold] : {trajet}")

@app.command()
def lister():
    utilisateurs = charger()
    table = Table(title="Réservations")

    table.add_column("Utilisateur", style="cyan")
    table.add_column("Trajet", style="green")
    table.add_column("Date", style="magenta")

    for u in utilisateurs:
        for r in u.reservations:
            table.add_row(u.nom, str(r["trajet"]), r["date"].strftime("%Y-%m-%d %H:%M:%S"))

    console.print(table)

@app.command()
def analyser():
    analyser_reservations()

@app.command()
def graphique():
    afficher_histogramme_utilisateurs()
    afficher_camembert_types()

if __name__ == "__main__":
    app()
