
# 🚀 Projet7 – Système de gestion de trajets et réservations

Ce projet pédagogique évolutif en Python a pour but de montrer comment structurer une application complète autour de la programmation orientée objet, des bibliothèques standard et de modules externes.

---

## 🧱 Fonctionnalités principales

- Gestion d'objets `Trajet`, `TrajetExpress`, `Utilisateur`
- Réservations avec date d'enregistrement
- Persistance des données (JSON → SQLite)
- Analyse avec `pandas` et export Excel
- Visualisation avec `matplotlib`
- Interface CLI moderne avec `typer` + `rich`
- Génération de rapport PDF avec `jinja2` + `weasyprint`
- Tests unitaires (`pytest`)
- Organisation modulaire (models, services, cli, tests)

---

## 📦 Dépendances

À installer dans un environnement virtuel :

```bash
pip install -r requirements.txt
```

Ou :

```bash
pip install pandas openpyxl matplotlib typer[all] rich weasyprint jinja2 pytest
```

---

## 🗂️ Structure du projet

```
projet7/
│
├── models/                  # Classes métier
├── services/                # Fonctions transverses (I/O, analyse, BDD, PDF)
├── templates/               # HTML pour génération de rapport PDF
├── tests/                   # Tests unitaires (pytest)
├── data/                    # Données JSON, Excel ou SQLite
├── logs/                    # Fichier log (actions.log)
├── cli.py                   # Interface terminale (typer)
├── main.py                  # Version principale JSON
├── main_db.py               # Version principale SQLite
├── pyproject.toml           # Déclaration du projet
└── README.md
```

---

## 🧪 Tester le projet

Lancer la version JSON :
```bash
python projet7/main.py
```

Lancer la version CLI :
```bash
python projet7/cli.py reserver --nom Alice --depart Paris --arrivee Lyon --distance 300
python projet7/cli.py lister
python projet7/cli.py analyser
python projet7/cli.py graphique
```

Lancer la version SQLite :
```bash
python projet7/main_db.py
```

Générer un PDF :
```bash
python projet7/services/rapport.py
```

Exécuter les tests :
```bash
pytest projet7/tests
```

---

## 📚 Étapes pédagogiques du projet

| Étape | Contenu                             |
|-------|-------------------------------------|
| 1     | Objets + JSON + Logging             |
| 2     | Analyse avec `pandas`               |
| 3     | Visualisation `matplotlib`          |
| 4     | Interface CLI `typer` + `rich`      |
| 5     | Rapport PDF avec `jinja2` + `weasyprint` |
| 6     | Tests unitaires `pytest`            |
| 7     | Persistance en base `SQLite`        |

---

## 👨‍🏫 Conçu pour la formation Python orientée objet

Ce projet a été pensé pour servir de **fil rouge pédagogique** lors d'une formation Python, du niveau intermédiaire jusqu’à l’avancé.

