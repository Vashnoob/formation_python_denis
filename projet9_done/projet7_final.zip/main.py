
from projet7.models.utilisateur import Utilisateur
from projet7.models.trajet import Trajet
from projet7.models.trajet_express import TrajetExpress
from projet7.services.persistence import sauvegarder, charger
from projet7.services.logger import log_info
from projet7.services.analyse import analyser_reservations
from projet7.services.visualisation import afficher_histogramme_utilisateurs, afficher_camembert_types

def main():
    utilisateurs = charger()

    if not utilisateurs:
        log_info("Initialisation des données")
        alice = Utilisateur("Alice")
        bob = Utilisateur("Bob")
        t1 = Trajet("Paris", "Lyon", 460)
        t2 = TrajetExpress("Paris", "Marseille", 750)
        t3 = Trajet("Lyon", "Nice", 470)

        alice.reserver(t1)
        alice.reserver(t2)
        bob.reserver(t3)

        utilisateurs.extend([alice, bob])
        sauvegarder(utilisateurs)

    for u in utilisateurs:
        u.afficher()

    analyser_reservations()
    afficher_histogramme_utilisateurs()
    afficher_camembert_types()

if __name__ == "__main__":
    main()
