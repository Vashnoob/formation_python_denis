
import sqlite3
from pathlib import Path
from datetime import datetime
from projet7.models.trajet import Trajet
from projet7.models.trajet_express import TrajetExpress
from projet7.models.utilisateur import Utilisateur

DB_PATH = Path(__file__).parent.parent / "data" / "reservations.db"

def initialiser_db():
    with sqlite3.connect(DB_PATH) as conn:
        cur = conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS utilisateurs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nom TEXT UNIQUE NOT NULL
            )
        """)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS trajets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                depart TEXT,
                arrivee TEXT,
                distance REAL,
                type TEXT
            )
        """)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS reservations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                utilisateur_id INTEGER,
                trajet_id INTEGER,
                date TEXT,
                FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id),
                FOREIGN KEY (trajet_id) REFERENCES trajets(id)
            )
        """)
        conn.commit()

def ajouter_utilisateur(nom):
    with sqlite3.connect(DB_PATH) as conn:
        cur = conn.cursor()
        cur.execute("INSERT OR IGNORE INTO utilisateurs (nom) VALUES (?)", (nom,))
        conn.commit()

def ajouter_trajet(trajet):
    with sqlite3.connect(DB_PATH) as conn:
        cur = conn.cursor()
        cur.execute("INSERT INTO trajets (depart, arrivee, distance, type) VALUES (?, ?, ?, ?)",
                    (trajet.depart, trajet.arrivee, trajet.distance, type(trajet).__name__))
        trajet_id = cur.lastrowid
        conn.commit()
        return trajet_id

def faire_reservation(nom_utilisateur, trajet):
    ajouter_utilisateur(nom_utilisateur)
    with sqlite3.connect(DB_PATH) as conn:
        cur = conn.cursor()
        cur.execute("SELECT id FROM utilisateurs WHERE nom = ?", (nom_utilisateur,))
        user_id = cur.fetchone()[0]
        trajet_id = ajouter_trajet(trajet)
        date = datetime.now().isoformat()
        cur.execute("INSERT INTO reservations (utilisateur_id, trajet_id, date) VALUES (?, ?, ?)",
                    (user_id, trajet_id, date))
        conn.commit()

def lister_reservations():
    with sqlite3.connect(DB_PATH) as conn:
        cur = conn.cursor()
        cur.execute("""
            SELECT u.nom, t.depart, t.arrivee, t.distance, t.type, r.date
            FROM reservations r
            JOIN utilisateurs u ON r.utilisateur_id = u.id
            JOIN trajets t ON r.trajet_id = t.id
            ORDER BY r.date DESC
        """)
        return cur.fetchall()
