
from projet7.services.db import initialiser_db, faire_reservation, lister_reservations
from projet7.models.trajet import Trajet
from projet7.models.trajet_express import TrajetExpress

initialiser_db()

faire_reservation("Alice", Trajet("Paris", "Lyon", 460))
faire_reservation("Bob", TrajetExpress("Paris", "Marseille", 750))

for r in lister_reservations():
    print(r)
