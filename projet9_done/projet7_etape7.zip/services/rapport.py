
from jinja2 import Environment, FileSystemLoader
from weasyprint import HTML
from projet7.services.persistence import charger
from pathlib import Path

def generer_pdf():
    utilisateurs = charger()
    template_dir = Path(__file__).parent / "templates"
    output_pdf = Path(__file__).parent.parent / "data" / "rapport_reservations.pdf"

    env = Environment(loader=FileSystemLoader(template_dir))
    template = env.get_template("rapport.html")

    html_content = template.render(utilisateurs=utilisateurs)
    HTML(string=html_content).write_pdf(str(output_pdf))
    print(f"✅ Rapport PDF généré : {output_pdf.resolve()}")

if __name__ == "__main__":
    generer_pdf()
