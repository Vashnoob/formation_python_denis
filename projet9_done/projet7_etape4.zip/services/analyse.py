
import pandas as pd
from projet7.models.utilisateur import Utilisateur
from projet7.models.trajet import Trajet
from projet7.models.trajet_express import TrajetExpress
from projet7.services.persistence import charger
from pathlib import Path

EXPORT_PATH = Path(__file__).parent.parent / "data" / "analyse_reservations.xlsx"

def analyser_reservations():
    utilisateurs = charger()
    lignes = []

    for u in utilisateurs:
        for r in u.reservations:
            trajet = r["trajet"]
            lignes.append({
                "Nom utilisateur": u.nom,
                "Départ": trajet.depart,
                "Arrivée": trajet.arrivee,
                "Distance": trajet.distance,
                "Durée estimée": trajet.calculer_duree(),
                "Type de trajet": type(trajet).__name__,
                "Date de réservation": r["date"]
            })

    df = pd.DataFrame(lignes)

    print("\n=== Aperçu des réservations ===")
    print(df.head())

    print("\n=== Réservations par utilisateur ===")
    print(df.groupby("Nom utilisateur").size())

    print("\n=== Distances moyennes par type ===")
    print(df.groupby("Type de trajet")["Distance"].mean())

    df.to_excel(EXPORT_PATH, index=False)
    print(f"Fichier Excel sauvegardé à : {EXPORT_PATH.resolve()}")
