
import matplotlib.pyplot as plt
from projet7.services.persistence import charger

def afficher_histogramme_utilisateurs():
    utilisateurs = charger()
    comptages = {}

    for u in utilisateurs:
        comptages[u.nom] = comptages.get(u.nom, 0) + len(u.reservations)

    noms = list(comptages.keys())
    nombres = list(comptages.values())

    plt.bar(noms, nombres, color='skyblue')
    plt.xlabel("Utilisateur")
    plt.ylabel("Nombre de réservations")
    plt.title("Nombre de réservations par utilisateur")
    plt.tight_layout()
    plt.show()

def afficher_camembert_types():
    utilisateurs = charger()
    types = {}

    for u in utilisateurs:
        for r in u.reservations:
            t = type(r["trajet"]).__name__
            types[t] = types.get(t, 0) + 1

    labels = list(types.keys())
    valeurs = list(types.values())

    plt.pie(valeurs, labels=labels, autopct="%1.1f%%", startangle=90)
    plt.title("Répartition des types de trajets")
    plt.axis("equal")
    plt.show()
