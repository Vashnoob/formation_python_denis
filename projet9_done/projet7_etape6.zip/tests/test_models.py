
import pytest
from projet7.models.trajet import Trajet
from projet7.models.trajet_express import TrajetExpress
from projet7.models.utilisateur import Utilisateur

def test_trajet_calcul_duree():
    t = Trajet("Paris", "Lyon", 800)
    assert t.calculer_duree() == 10.0

def test_trajet_express_duree():
    t = TrajetExpress("Paris", "Lyon", 750)
    assert t.calculer_duree() == 5.0

def test_utilisateur_reservation():
    u = Utilisateur("Alice")
    t = Trajet("Paris", "Lyon", 460)
    u.reserver(t)
    assert len(u.reservations) == 1
    assert u.reservations[0]["trajet"].depart == "Paris"
    assert u.reservations[0]["trajet"].arrivee == "Lyon"
